#ifndef UTIL_H_
#define UTIL_H_

#define MIN(X,Y) ((X) < (Y) ? (X) : (Y))

/*
 * Milliseconds till start of unix time stamp
 */
unsigned long current_time_millis();

#endif
